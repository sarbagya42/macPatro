This is a simple but elegant MacOS widget for Nepali Date.
How to use it?
Step1: Download and install Übersicht, Step2: Add the hamropatro.jsx and nepal.png to the Übersicht Widget Folder, Step3: Update all Widgets.

<img width="615" alt="Screenshot 2024-09-18 at 22 58 45" src="https://github.com/user-attachments/assets/9d9bad8b-09e6-4277-8ddb-b8f7942902e8">


<img width="699" alt="Screenshot 2024-09-18 at 19 11 32" src="https://github.com/user-attachments/assets/3100b387-342b-44d0-9a77-6dfc6e081e2d">

